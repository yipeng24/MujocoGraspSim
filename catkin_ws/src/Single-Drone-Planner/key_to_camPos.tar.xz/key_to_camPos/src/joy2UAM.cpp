/*
  MIT License

  Copyright (c) 2021 Hongkai Ye (kyle_yeh@163.com, hkye@zju.edu.cn)

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
*/
#include <Eigen/Eigen>
#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Joy.h>
#include "tf/tf.h"
#include <quadrotor_msgs/UAMFullState.h>
#include <quadrotor_msgs/ArmAnglesState.h>
#include <std_msgs/Bool.h>

#define CH_FORWARD 0
#define CH_LEFT 1
#define CH_UP 2
#define CH_CONFIRM 3
#define CH_YAW 4
#define CH_PITCH 5
#define CH_PITCH2 6
#define CH_ROLL 7

#define BUTTON_EXCUTE_MODE 6
#define BUTTON_GRAB 1

ros::Publisher uam_goal_vis_pub_, uam_goal_cmd_pub_, thetas_cmd_pub_, grab_cmd_pub_;
ros::Subscriber joy_sub_;
ros::Timer uam_vis_timer_;
int uam_vis_rate_ = 50.0;
double uam_vis_cyc_;

quadrotor_msgs::UAMFullState uam_state_msg_;

sensor_msgs::Joy rcv_joy_msg_;
bool have_joy_ = false;
bool in_auto_excute_mode_ = false;
bool grab_ = false;

double yaw_=0;
Eigen::Vector3d thetas_;

std::vector<std::string> joint_names_ = {"arm_joint_pitch", 
                                        "arm_joint_pitch2", 
                                        "arm_joint_roll"};

void angLimit(double& ang)
{
  ang = ang > M_PI ? ang - 2*M_PI : ang;
  ang = ang <-M_PI ? ang + 2*M_PI : ang;
}

void thetasLimit(Eigen::Vector3d& thetas)
{
  Eigen::Vector3d thetas_low, thetas_high;
  thetas_low << 0, -M_PI/2, -M_PI/2;
  thetas_high << M_PI/2, M_PI/2, M_PI/2;

    for (int i = 0; i < 3; ++i)
    {
        if (thetas[i] < thetas_low[i])  thetas[i] = thetas_low[i];
        if (thetas[i] > thetas_high[i]) thetas[i] = thetas_high[i];
    }
}


void rcvJoyCallbck(const sensor_msgs::Joy &joy_msg)
{
  have_joy_ = true;

  if(joy_msg.buttons.at(BUTTON_EXCUTE_MODE)){
    in_auto_excute_mode_ = !in_auto_excute_mode_;
    std::cout << "[ExcuteMode] " << in_auto_excute_mode_ << std::endl;
    return;
  }

  if(joy_msg.buttons.at(BUTTON_GRAB)){
    grab_ = !grab_;
    std::cout << "[Grab] " << grab_ << std::endl;
    return;
  }

  // TODO
  rcv_joy_msg_ = joy_msg;

  if (joy_msg.axes.at(CH_CONFIRM)>0.5)
    uam_goal_cmd_pub_.publish(uam_state_msg_);

  return;
}

void pub_thetas_cmd(const quadrotor_msgs::UAMFullState& uam_state_msg){
  quadrotor_msgs::ArmAnglesState thetas_cmd_msg;
  for(size_t i=0; i<joint_names_.size(); ++i){
    thetas_cmd_msg.thetas.push_back(uam_state_msg.thetas[i]);
    thetas_cmd_msg.dthetas.push_back(uam_state_msg.dthetas[i]);
  }
  thetas_cmd_pub_.publish(thetas_cmd_msg);

  std_msgs::Bool grab_msg;
  grab_msg.data = true ? grab_ : false;
  grab_cmd_pub_.publish(grab_msg);
}

void UAMStatePubCallbck(const ros::TimerEvent& event){

  if(!have_joy_){
    uam_goal_vis_pub_.publish(uam_state_msg_);
    return;
  }

  uam_state_msg_.header.stamp = ros::Time::now();

  // * get position
  Eigen::Vector3d T_b,T_w; //单位时间平移
  T_b << rcv_joy_msg_.axes.at(CH_FORWARD), rcv_joy_msg_.axes.at(CH_LEFT), rcv_joy_msg_.axes.at(CH_UP);
  T_b*=uam_vis_cyc_;

  Eigen::Matrix2d R_b2w_2d;
  R_b2w_2d << cos(yaw_),-sin(yaw_),
              sin(yaw_), cos(yaw_);

  T_w.head(2) = R_b2w_2d*T_b.head(2);
  T_w.z() = T_b.z();

  uam_state_msg_.pose.position.x += T_w.x();
  uam_state_msg_.pose.position.y += T_w.y();
  uam_state_msg_.pose.position.z += T_w.z();

  // * get yaw
  yaw_ += uam_vis_cyc_*rcv_joy_msg_.axes.at(CH_YAW);

  angLimit(yaw_);
  Eigen::Quaterniond q_b2w,q_c2b,q_c2w;
  q_b2w = Eigen::AngleAxisd(yaw_, Eigen::Vector3d::UnitZ());

  uam_state_msg_.pose.orientation.w = q_b2w.w();
  uam_state_msg_.pose.orientation.x = q_b2w.x();
  uam_state_msg_.pose.orientation.y = q_b2w.y();
  uam_state_msg_.pose.orientation.z = q_b2w.z();

  // * get thetas
  Eigen::Vector3d thetas_add;
  thetas_add << rcv_joy_msg_.axes.at(CH_PITCH), rcv_joy_msg_.axes.at(CH_PITCH2), rcv_joy_msg_.axes.at(CH_ROLL);
  thetas_ += thetas_add*uam_vis_cyc_;
  thetasLimit(thetas_);
  uam_state_msg_.thetas[0] = thetas_.x();
  uam_state_msg_.thetas[1] = thetas_.y();
  uam_state_msg_.thetas[2] = thetas_.z();
  uam_state_msg_.thetas[3] = 1.0 ? grab_ : 0.0;

  uam_state_msg_.dthetas[0] = 0;
  uam_state_msg_.dthetas[1] = 0;
  uam_state_msg_.dthetas[2] = 0;

  uam_goal_vis_pub_.publish(uam_state_msg_);

  // pub thetas cmd
  if(!in_auto_excute_mode_)
    pub_thetas_cmd(uam_state_msg_);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "joy2camPos");
  ros::NodeHandle nh("~");

  thetas_.setZero();
  uam_state_msg_.header.frame_id = "world";
  uam_state_msg_.pose.position.x = 0.0;
  uam_state_msg_.pose.position.y = 0.0;
  uam_state_msg_.pose.position.z = 1.0;
  uam_state_msg_.pose.orientation.w = 1.0;
  uam_state_msg_.pose.orientation.x = 0.0;
  uam_state_msg_.pose.orientation.y = 0.0;
  uam_state_msg_.pose.orientation.z = 0.0;
  uam_state_msg_.thetas.push_back(0);
  uam_state_msg_.thetas.push_back(0);
  uam_state_msg_.thetas.push_back(0);
  uam_state_msg_.thetas.push_back(0);
  uam_state_msg_.dthetas.push_back(0);
  uam_state_msg_.dthetas.push_back(0);
  uam_state_msg_.dthetas.push_back(0);
  uam_state_msg_.dthetas.push_back(0);

  std::cout << "joy2camPos node started." << std::endl;

  joy_sub_ = nh.subscribe("/joy", 1, rcvJoyCallbck);
  grab_cmd_pub_ = nh.advertise<std_msgs::Bool>("/arm_grab_cmd", 1);
  thetas_cmd_pub_ = nh.advertise<quadrotor_msgs::ArmAnglesState>("/arm_angles_cmd", 1);
  uam_goal_vis_pub_ = nh.advertise<quadrotor_msgs::UAMFullState>("uam_state_goal_vis", 1);
  uam_goal_cmd_pub_ = nh.advertise<quadrotor_msgs::UAMFullState>("uam_state_goal_cmd", 1);
  uam_vis_cyc_ = 1./(double)uam_vis_rate_;
  uam_vis_timer_ = nh.createTimer(ros::Duration(uam_vis_cyc_),&UAMStatePubCallbck);

  ros::spin();
}
